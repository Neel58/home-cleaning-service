import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = 'django-insecure-change-this-in-production-xyz123'

DEBUG = True

ALLOWED_HOSTS = ['*', 'localhost', '127.0.0.1']

INSTALLED_APPS = [
     'jazzmin', 
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'cleaning',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'cleanhome_project.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'django.template.context_processors.csrf',
                'cleaning.context_processors.user_profile_context',
                'cleaning.context_processors.notifications_context',
            ],
        },
    },
]

WSGI_APPLICATION = 'cleanhome_project.wsgi.application'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]

JAZZMIN_SETTINGS = {
    "site_title": "CleanHome Admin",
    "site_header": "CleanHome Dashboard",
    "site_brand": "CleanHome",
    "welcome_sign": "Welcome to CleanHome Admin",

    "topmenu_links": [
        {"name": "Home", "url": "admin:index", "new_window": False},
        {"name": "Analytics", "url": "/dashboard/analytics/", "new_window": False},
    ],

    "show_sidebar": True,
    "navigation_expanded": True,

    "footer_links": [],
    "copyright": "CleanHome Services © 2026",
    "show_ui_builder": False,
    
    "icons": {
        "auth.User": "fas fa-user",
        "cleaning.Booking": "fas fa-calendar",
        "cleaning.Service": "fas fa-broom",
        "cleaning.Payment": "fas fa-money-bill",
        "cleaning.Review": "fas fa-star",
        "cleaning.UserProfile": "fas fa-id-card",
    },

    "theme": "darkly",   # 🔥 TRY: darkly, cyborg, flatly, minty
}

LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Asia/Kolkata'
USE_I18N = True
USE_TZ = True

STATIC_URL = '/static/'
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')
STATICFILES_DIRS = [
    os.path.join(BASE_DIR, 'static'),
]

MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

LOGIN_URL = 'login'
LOGIN_REDIRECT_URL = 'logged_in_home'

# ======================== EMAIL CONFIGURATION ========================
# For development: use file-based backend to save emails to files
# EMAIL_BACKEND = 'django.core.mail.backends.filebased.EmailBackend'
# EMAIL_FILE_PATH = os.path.join(BASE_DIR, 'sent_emails')

# For console output (development without files):
# EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# Real Email Configuration (Gmail SMTP)
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_PORT = 587
EMAIL_USE_TLS = True
EMAIL_HOST_USER = 'neldshah05@gmail.com'  # Your Gmail address
EMAIL_HOST_PASSWORD = 'usty hcex qyeq sere'  # Your 16-character App Password
DEFAULT_FROM_EMAIL = 'CleanHome Service <neldshah05@gmail.com>' # Matches your Gmail



# ======================== SECURITY SETTINGS ========================
# Session settings
SESSION_COOKIE_SECURE = False  # Set to True in production with HTTPS
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_AGE = 1209600  # 2 weeks in seconds (default Django value)
SESSION_EXPIRE_AT_BROWSER_CLOSE = False  # Keep session even if browser closes
SESSION_COOKIE_SAMESITE = 'Lax'  # CSRF protection
CSRF_COOKIE_SECURE = False  # Set to True in production with HTTPS
CSRF_COOKIE_HTTPONLY = True
CSRF_COOKIE_SAMESITE = 'Lax'

# Message storage
MESSAGE_STORAGE = 'django.contrib.messages.storage.session.SessionStorage'

# Security headers
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_SECURITY_POLICY = {
    'default-src': ('\'self\'',),
    'script-src': ('\'self\'', '\'unsafe-inline\'', 'cdn.jsdelivr.net', 'code.jquery.com'),
    'style-src': ('\'self\'', '\'unsafe-inline\'', 'cdn.jsdelivr.net'),
    'img-src': ('\'self\'', 'data:', 'https:'),
    'font-src': ('\'self\'', 'cdn.jsdelivr.net'),
}

# ======================== PASSWORD RESET SETTINGS ========================
PASSWORD_RESET_TIMEOUT = 3600  # 1 hour in seconds
# ======================== ERROR HANDLER SETTINGS ========================
# Custom error page handlers
handler404 = 'cleaning.views.error_404'
handler403 = 'cleaning.views.error_403'
handler500 = 'cleaning.views.error_500'